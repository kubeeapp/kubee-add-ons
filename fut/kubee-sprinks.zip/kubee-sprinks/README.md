# Kubee Sprinks

Kubee Sprinks, Smart Irrigation Controller for Kubee Grow Assistant, Hassio Add-on.
